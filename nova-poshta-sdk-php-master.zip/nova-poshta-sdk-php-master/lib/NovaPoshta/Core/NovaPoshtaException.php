<?php

namespace NovaPoshta\Core;

class NovaPoshtaException extends \Exception
{

}