<?php

namespace NovaPoshta\Core;

/**
 * Class Helper
 * @package NovaPoshta\Core
 */
class Helper
{

}
